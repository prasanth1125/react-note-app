import {makeStyles} from '@material-ui/core/styles';

const useStyles = makeStyles((theme) => ({
    container: {
        backgroundColor: theme.palette.background.paper,
        padding: theme.spacing(8,0,6)
    },
    icon: {
        marginRight: '20px'
    },
    buttons: {
        marginTop: '40px'
    },
    cardGrid:{
        padding: '20px 0'
    },
    card: { 
        height: '100%',
        display: 'flex',
        borderRadius: '30px',
        transition: '0.5s ease',
        cursor: 'pointer',
        flexDirection: 'column',
        background: 'linear-gradient(to right, #cc95c0, #dbd4b4, #7aa1d2)',
        '&:hover': {
            boxShadow: '10px 10px 15px 0 rgba(200, 25, 10, 0.8)',
            transform: 'scale(0.9)'
         }
    },  
    cardMedia: {
        paddingTop: '56.25%'
    },
    cardContent: {
        flexGrow: 1
    },
    filterButtonSize: {
        width: '15%',
        backgroundColor: '#fca311',
        margin: '1rem'
    },
    formHeader: {
        background: '#023e8a',
        color: 'white',
    },
    dropDownSelector: {
        width: '160px'
    }
}));

export default useStyles;