import { configureStore } from '@reduxjs/toolkit';

import noteSlice from './notes-store'; //used alias for the reducer


//this configureStore is used here to combine the reducer functions 
// this has the object with reducer property 
// notes -> this is a slice for the reducer function 
const store = configureStore({
   reducer: {
      notes: noteSlice.reducer,
   }
});

export default store;