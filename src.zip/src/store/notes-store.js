import {createSlice} from '@reduxjs/toolkit';


const noteSlice = createSlice({
   name: 'note',
   initialState: {
      noteItems: [],
      filteredNotes: [],
      cardUiState: false,
      updateCard: false
   },
   reducers: {
      addNote(state,action) {
         const newItem = action.payload;
         state.noteItems.push({
            id: newItem.id,
            title: newItem.title,
            noteDes: newItem.noteDes,
            noteTag: newItem.noteTag,
         });
      },

      deleteNote(state, action){
        const ids = action.payload;
        state.noteItems = state.noteItems.filter((item) => item.id !== ids);
        state.filteredNotes = state.filteredNotes.filter((item) => item.id !== ids);
      },

      filterNote(state,action) {
         const tagFilter = action.payload;
         const noteItems = state.noteItems.filter((item) => item.noteTag === tagFilter);
         state.filteredNotes = noteItems;
      },

      toggleCardUi(state,action){
         state.cardUiState = action.payload;
      },

      updateNote(state,action){
         state.noteItems = state.noteItems.map((note) => {
            const newItem = action.payload;
            if (note.id === newItem.id) {
                   return{
                      ...note,
                     id: newItem.id,
                     title: newItem.title,
                     noteDes: newItem.noteDes,
                     noteTag: newItem.noteTag}
            } else {
                return note;
            }
        });
        state.filteredNotes = state.filteredNotes.map((note) => {
         const newItem = action.payload;
         if (note.id === newItem.id) {
                return{
                   ...note,
                  id: newItem.id,
                  title: newItem.title,
                  noteDes: newItem.noteDes,
                  noteTag: newItem.noteTag}
         } else {
             return note;
         }
     });

      },

      toggleUpdateForm(state,action) {
         state.updateCard = action.payload;
      }

      }
   });

export const noteSliceAction =  noteSlice.actions; // extracting the reducers


export default noteSlice;  //here we just export the reducer object