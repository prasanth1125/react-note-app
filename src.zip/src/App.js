import './App.css';
import CreateButton from './components/CreateButton';
import NotesCard from './components/NotesCard';


function App() {
  return (
    <div className="App">
      <CreateButton />
      <NotesCard  />
    </div>
  );
}

export default App;
