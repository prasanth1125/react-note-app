import { useDispatch } from 'react-redux';
import { noteSliceAction } from '../store/notes-store';
import Button from '@material-ui/core/Button';
import TextField from '@material-ui/core/TextField';
import Dialog from '@material-ui/core/Dialog';
import DialogActions from '@material-ui/core/DialogActions';
import DialogContent from '@material-ui/core/DialogContent';
import DialogContentText from '@material-ui/core/DialogContentText';
import DialogTitle from '@material-ui/core/DialogTitle';
import InputLabel from '@material-ui/core/InputLabel';
import Select from '@material-ui/core/Select';
import MenuItem from '@material-ui/core/MenuItem';
import { useSelector } from 'react-redux';
import { useState } from 'react';  
import useStyles from '../styles';

const UpdateButton = (props) => {
   const dispatch = useDispatch();
   const classes = useStyles();
   const updateFormState = useSelector((state) => state.notes.updateCard);
   const [form, setForm] = useState({
      id: '',
      title: "",
      noteDes: "",
      noteTag: ''
    });

    const handleChange = (e) => {
      const { name, value } = e.target;
  
      let newForm = { ...form };
      newForm[name] = value;
  
      setForm(newForm);
    }
  

   const handleClose = () => {
      dispatch(noteSliceAction.toggleUpdateForm(false));
   }

   const submitHandler = (event) => {

      event.preventDefault();

      if(form.title.trim().length === 0){
         return;
      }else if(form.noteDes.trim().length === 0 ){
         return;
      }else if(form.noteTag.trim().length === 0 ){
         return;
      }

      const newNote = {
         id:props.id,
         title: form.title,
         noteDes: form.noteDes,
         noteTag: form.noteTag
      }

      //console.log(newNote);
      dispatch(noteSliceAction.updateNote(newNote));

      setForm({         //state has been reset 
         id: '',
         title: "",
         noteDes: "",
         noteTag: ''
         })
   }


   return(
      
    <Dialog open={updateFormState}  onClose={handleClose} aria-labelledby="form-dialog-title">
      
      <DialogTitle className={classes.formHeader} >Add notes here...</DialogTitle>
      <form onSubmit={submitHandler} >
        <DialogContent className={classes.formInputs}>
          <DialogContentText>
            please enter the notes as you wish
          </DialogContentText>
          
          <TextField
            autoFocus
            margin="dense"
            label="title"
            type="text"
            name= 'title'
            onChange={handleChange}
            value={form.title}
            fullWidth
          />
          
          <TextField
            autoFocus
            margin="dense"
            label="notes"
            type="text"
            onChange={handleChange}
            value={form.noteDes}
            name='noteDes'
            fullWidth
           
          />

        <InputLabel >select a tag</InputLabel>
        <Select
          onChange={handleChange}
          name="noteTag"
          value={form.noteTag}
          className={classes.dropDownSelector}
        >
          <MenuItem value='important'>important</MenuItem>
          <MenuItem value='less-important'>less-important</MenuItem>
        </Select>
          
        </DialogContent>
        <DialogActions>
          <Button onClick={handleClose} color="primary" >
            Cancel
          </Button>
          <Button type='submit'  color="primary">
            update
          </Button>
        </DialogActions>
        
      </form>

    </Dialog>
      
   );
};


export default UpdateButton;