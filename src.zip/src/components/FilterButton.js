import React from 'react';
import { makeStyles } from '@material-ui/core/styles';
import InputLabel from '@material-ui/core/InputLabel';
import MenuItem from '@material-ui/core/MenuItem';
import FormControl from '@material-ui/core/FormControl';
import Select from '@material-ui/core/Select';
import { useDispatch } from 'react-redux'
import { noteSliceAction } from '../store/notes-store';

const useStyles = makeStyles((theme) => ({
   formControl: {
     margin: theme.spacing(3),
      minWidth: 120,
      marginTop: '20px',
      backgroundColor: 'lightblue',
     
   },
   selectEmpty: {
     marginTop: theme.spacing(2),
   },
   
 }));
 


const FilterButton = (props) => {
   const dispatch = useDispatch();
   const classes = useStyles();
   
   const noteTagHandler = (event) => {
      const tagFetched = event.target.value;
      //console.log(tagFetched)
      dispatch(noteSliceAction.filterNote(tagFetched));
      dispatch(noteSliceAction.toggleCardUi(false));
   };

   return(
      <div  >
       <FormControl  variant='outlined' className={classes.formControl} >
        <InputLabel id="demo-simple-select-outlined-label">Filter</InputLabel>
        <Select
          labelId="demo-simple-select-outlined-label"
          id="demo-simple-select-outlined"
          value=''
          onChange={noteTagHandler}
          label="Filter"
        >
          <MenuItem value='important'>Important</MenuItem>
          <MenuItem value='less-important'>Less Important</MenuItem> 
        </Select>
      </FormControl>
    </div>
   );
};

export default FilterButton;