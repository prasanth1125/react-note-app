import { useState } from 'react';
import { useDispatch } from 'react-redux';
import { noteSliceAction } from '../store/notes-store';
import FilterButton from './FilterButton';
import Button from '@material-ui/core/Button';
import TextField from '@material-ui/core/TextField';
import Dialog from '@material-ui/core/Dialog';
import DialogActions from '@material-ui/core/DialogActions';
import DialogContent from '@material-ui/core/DialogContent';
import DialogContentText from '@material-ui/core/DialogContentText';
import DialogTitle from '@material-ui/core/DialogTitle';
import InputLabel from '@material-ui/core/InputLabel';
import Select from '@material-ui/core/Select';
import MenuItem from '@material-ui/core/MenuItem';
import useStyles from '../styles';

const CreatePopUp = (props) => {
  const dispatch = useDispatch();
  const classes = useStyles();
  const [open, setOpen] = useState(false);
  const [form, setForm] = useState({
    id: Math.random(),
    title: "",
    noteDes: "",
    noteTag: ''
  });

  const handleChange = (e) => {
    const { name, value } = e.target;

    let newForm = { ...form };
    newForm[name] = value;

    setForm(newForm);
  }

  

  const submitHandler = (event) => {
    event.preventDefault();
    if(form.title.trim().length === 0){
      return;
   }else if(form.noteDes.trim().length === 0 ){
      return;
   }else if(form.noteTag.trim().length === 0 ){
      return;
   }
    const newNote = {
      id: form.id,
      title: form.title,
      noteDes: form.noteDes,
      noteTag: form.noteTag
   }
   
   //console.log(newNote);
   dispatch(noteSliceAction.addNote(newNote));
   dispatch(noteSliceAction.toggleCardUi(true))
   setForm({         //state has been reset 
    id:Math.random(),
    title: "",
    noteDes: "",
    noteTag: ''
    })
  }

  const handleClickOpen = () => {
    setOpen(true);
  };

  const handleClose = () => {
    setOpen(false);
  };

  return (
    <div>
      <Button variant="contained" color="primary" onClick={handleClickOpen}>
        Create a Note
      </Button>

      <FilterButton />

      <Dialog open={open} onClose={handleClose}   aria-labelledby="form-dialog-title">
      
      <DialogTitle  className={classes.formHeader} >Add notes here...</DialogTitle>
      <form onSubmit={submitHandler} >
        <DialogContent className={classes.formInputs} >
          <DialogContentText>
            please enter the notes as you wish
          </DialogContentText>
          
          <TextField
            autoFocus
            margin="dense"
            label="title"
            type="text"
            name= 'title'
            value={form.title}
            onChange={handleChange}
            fullWidth
          />
          
          <TextField
            autoFocus
            margin="dense"
            label="notes"
            type="text"
            value={form.noteDes}
            name='noteDes'
            fullWidth
            onChange={handleChange}
          />

        <InputLabel >select a tag</InputLabel>
        <Select
          onChange={handleChange}
          value={form.noteTag}
          name="noteTag"
          className={classes.dropDownSelector}
        >
          <MenuItem value='important'>important</MenuItem>
          <MenuItem value='less-important'>less-important</MenuItem>
        </Select>
          
        </DialogContent>
        <DialogActions className={classes.formInputs}>
          <Button onClick={handleClose} color="primary" >
            Cancel
          </Button>
          <Button type='submit'  color="primary">
            Add
          </Button>
        </DialogActions>
        
        </form>

      </Dialog>
    </div>
  );
}

export default CreatePopUp;