import React from 'react';
import { makeStyles } from '@material-ui/core/styles';
import Avatar from '@material-ui/core/Avatar';
import Chip from '@material-ui/core/Chip';
import DoneIcon from '@material-ui/icons/Done';
import { deepOrange, green } from '@material-ui/core/colors';
import AssignmentIcon from '@material-ui/icons/Assignment';

const useStyles = makeStyles((theme) => ({
   root: {
      display: 'flex',
      marginRight: '120px',
      marginLeft: '100px',
      justifyContent: 'center',
      flexWrap: 'wrap',
      '& > *': {
       margin: theme.spacing(0.5),
     },
   },
   square: {
    color: theme.palette.getContrastText(deepOrange[500]),
    backgroundColor: deepOrange[500],
  },
  rounded: {
    color: '#fff',
    backgroundColor: green[500],
  },

 }));


const ChipTag = (props) => {
   const classes = useStyles();
 
   const handleDelete = () => {
     console.info('You clicked the delete icon.');
   };

   return (
     <div className={classes.root}>
       <Chip
        avatar={<Avatar variant="rounded" className={classes.rounded}>
        <AssignmentIcon />
      </Avatar>}
        label={props.tagNote}
        clickable
        color="secondary"
        onDelete={handleDelete}
        deleteIcon={<DoneIcon />}
      />
     </div>
   );
 }

 export default ChipTag;