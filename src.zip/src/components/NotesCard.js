import { useDispatch } from 'react-redux';
import { noteSliceAction } from '../store/notes-store';
import { Typography, Button, Card, CardActions, CardContent, CardMedia, Grid,  Container } from '@material-ui/core';
import useStyles from '../styles';
import { useSelector } from 'react-redux';
import ChipTag from './ChipTag';
import UpdateButton from './UpdateButton';
import { useState } from 'react'
 


const NotesCard = (props) => {
  const [ idState, setId ] = useState();
   const classes = useStyles();
   const filteredNotes = useSelector( (state) => state.notes.filteredNotes);
   const allNotes = useSelector((state) => state.notes.noteItems);
   const cardUiStateHandler = useSelector((state) => state.notes.cardUiState);
   const updateFormState = useSelector((state) => state.notes.updateCard);

   const dispatch = useDispatch();

   const deleteNoteHandler = (id) => {
      dispatch(noteSliceAction.deleteNote(id));
      //console.log(id);
   };

   const  toggleUpdateHandler = (id) => {
      dispatch(noteSliceAction.toggleUpdateForm(true))
      //console.log(id)
      setId(id)
   };

 
   return(
      <Container className={classes.cardGrid} maxWidth='md'>
      <Grid container spacing={4}>

          {cardUiStateHandler && allNotes.map((card) => (<Grid item key={card.id} xs={12} sm={6} md={4} id={card.id} >
            <Card className={classes.card}>
              <CardMedia
                className={classes.cardMedia}
                image='https://source.unsplash.com/random'
                title='image title' 
              />
              <CardContent className={classes.cardContent}>
                <Typography gutterBottom variant='h4' color='primary'>
                  {card.title}
                </Typography>
                <ChipTag tagNote={card.noteTag}   />
                <Typography  gutterBottom variant='h6' color='secondary'>{card.noteDes}</Typography>
              </CardContent>
              <CardActions>
                <Button size='small' color='primary' onClick={(id) => toggleUpdateHandler(card.id)} >Edit  </Button>
                <Button size='small' color='primary' onClick={(id) => deleteNoteHandler(card.id)} >delete</Button>
              </CardActions>
            </Card>
          </Grid>
          ))}

          { updateFormState && <UpdateButton id={idState}/>}

        {!cardUiStateHandler && filteredNotes.map((card) => (<Grid item key={card.id} xs={12} sm={6} md={4} id={card.id} >
          <Card className={classes.card}>
            <CardMedia
              className={classes.cardMedia}
              image='https://source.unsplash.com/random'
              title='image title' 
            />
            <CardContent className={classes.cardContent}>
              <Typography gutterBottom variant='h4' color='primary'>
               {card.title}
              </Typography>
              <ChipTag tagNote={card.noteTag}  />
              <Typography  gutterBottom variant='h6' color='secondary'>{card.noteDes}</Typography>
            </CardContent>
            <CardActions>
              <Button size='small' color='primary' onClick={(id) => toggleUpdateHandler(card.id)} > Edit {updateFormState && <UpdateButton id={card.id}/>} </Button>
              <Button size='small' color='primary' onClick={(id) => deleteNoteHandler(card.id)} >delete</Button>
            </CardActions>
          </Card>
        </Grid>
        ))}
         { updateFormState && <UpdateButton id={idState}/>}
      </Grid>
    </Container>
   );
   
};

export default NotesCard;